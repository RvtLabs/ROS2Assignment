#!/usr/bin/env python3
"""
frontier_explorer.py

Simple frontier-based autonomous exploration node.

Subscribes to the live /map (nav_msgs/OccupancyGrid) published by
slam_toolbox, finds "frontier" cells -- free cells that border unknown
(unmapped) space -- clusters them into contiguous regions, and sends the
nearest sufficiently large cluster's centroid to Nav2 as a NavigateToPose
goal. Repeats automatically until no reachable frontiers remain, at which
point the map is considered fully explored and the node stops sending
goals.

No manual driving required: this node + slam.launch.py + navigation.launch.py
together give autonomous SLAM mapping.
"""

import math
import time
from collections import deque

import numpy as np
import rclpy
from action_msgs.msg import GoalStatus
from nav2_msgs.action import NavigateToPose
from nav_msgs.msg import OccupancyGrid
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import (
    QoSDurabilityPolicy,
    QoSHistoryPolicy,
    QoSProfile,
    QoSReliabilityPolicy,
)
from tf2_ros import (
    Buffer,
    ConnectivityException,
    ExtrapolationException,
    LookupException,
    TransformListener,
)

FREE = 0
OCCUPIED = 100
UNKNOWN = -1


class FrontierExplorer(Node):

    def __init__(self):
        super().__init__('frontier_explorer')

        self.declare_parameter('map_topic', 'map')
        self.declare_parameter('global_frame', 'map')
        self.declare_parameter('robot_base_frame', 'base_footprint')
        self.declare_parameter('min_frontier_size', 6)       # cells
        self.declare_parameter('min_goal_distance', 0.5)     # m
        self.declare_parameter('goal_timeout', 45.0)         # s
        self.declare_parameter('exploration_rate', 2.0)      # s between planning attempts
        self.declare_parameter('no_frontier_stop_count', 3)  # consecutive empty scans before stopping

        self.map_topic = self.get_parameter('map_topic').value
        self.global_frame = self.get_parameter('global_frame').value
        self.robot_base_frame = self.get_parameter('robot_base_frame').value
        self.min_frontier_size = self.get_parameter('min_frontier_size').value
        self.min_goal_distance = self.get_parameter('min_goal_distance').value
        self.goal_timeout = self.get_parameter('goal_timeout').value
        self.exploration_rate = self.get_parameter('exploration_rate').value
        self.no_frontier_stop_count = self.get_parameter('no_frontier_stop_count').value

        map_qos = QoSProfile(
            reliability=QoSReliabilityPolicy.RELIABLE,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=1,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
        )
        self.map_sub = self.create_subscription(
            OccupancyGrid, self.map_topic, self._map_callback, map_qos
        )

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        self.latest_map = None
        self.visited_frontiers = []
        self.goal_active = False
        self.goal_start_time = 0.0
        self.current_goal_handle = None
        self.empty_scan_count = 0
        self.exploring = True

        self.timer = self.create_timer(self.exploration_rate, self._exploration_step)
        self.get_logger().info(
            'Frontier explorer started; waiting for /map and the '
            'navigate_to_pose action server...'
        )

    # ---------- ROS callbacks ----------

    def _map_callback(self, msg: OccupancyGrid):
        self.latest_map = msg

    def _get_robot_pose(self):
        try:
            t = self.tf_buffer.lookup_transform(
                self.global_frame, self.robot_base_frame, rclpy.time.Time()
            )
            return t.transform.translation.x, t.transform.translation.y
        except (LookupException, ConnectivityException, ExtrapolationException) as exc:
            self.get_logger().warn(f'TF lookup {self.global_frame}->{self.robot_base_frame} failed: {exc}')
            return None

    # ---------- Frontier detection ----------

    def _find_frontier_cells(self, grid: np.ndarray):
        """Free cells that are 4-adjacent to at least one unknown cell."""
        free_mask = grid == FREE
        unknown_mask = grid == UNKNOWN

        neighbor_unknown = np.zeros_like(unknown_mask)
        neighbor_unknown[1:, :] |= unknown_mask[:-1, :]
        neighbor_unknown[:-1, :] |= unknown_mask[1:, :]
        neighbor_unknown[:, 1:] |= unknown_mask[:, :-1]
        neighbor_unknown[:, :-1] |= unknown_mask[:, 1:]

        frontier_mask = free_mask & neighbor_unknown
        rows, cols = np.nonzero(frontier_mask)
        return list(zip(rows.tolist(), cols.tolist())), frontier_mask

    def _cluster_frontiers(self, frontier_cells, frontier_mask):
        """Group frontier cells into 4-connected clusters via BFS."""
        visited = np.zeros_like(frontier_mask, dtype=bool)
        cell_set = set(frontier_cells)
        clusters = []

        for cell in frontier_cells:
            if visited[cell]:
                continue
            cluster = []
            q = deque([cell])
            visited[cell] = True
            while q:
                r, c = q.popleft()
                cluster.append((r, c))
                for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    n = (r + dr, c + dc)
                    if n in cell_set and not visited[n]:
                        visited[n] = True
                        q.append(n)
            clusters.append(cluster)
        return clusters

    @staticmethod
    def _cell_to_world(row, col, map_msg: OccupancyGrid):
        res = map_msg.info.resolution
        ox = map_msg.info.origin.position.x
        oy = map_msg.info.origin.position.y
        return ox + (col + 0.5) * res, oy + (row + 0.5) * res

    # ---------- Main loop ----------

    def _exploration_step(self):
        if not self.exploring:
            return

        if self.goal_active:
            if time.time() - self.goal_start_time > self.goal_timeout:
                self.get_logger().warn('Exploration goal timed out; cancelling.')
                self._cancel_current_goal()
            return

        if self.latest_map is None:
            return

        if not self.nav_client.server_is_ready():
            self.get_logger().info('Waiting for /navigate_to_pose action server...')
            return

        pose = self._get_robot_pose()
        if pose is None:
            return
        rx, ry = pose

        map_msg = self.latest_map
        width, height = map_msg.info.width, map_msg.info.height
        grid = np.array(map_msg.data, dtype=np.int8).reshape((height, width))

        frontier_cells, frontier_mask = self._find_frontier_cells(grid)
        if not frontier_cells:
            self._handle_no_frontiers()
            return

        clusters = [
            c for c in self._cluster_frontiers(frontier_cells, frontier_mask)
            if len(c) >= self.min_frontier_size
        ]
        if not clusters:
            self._handle_no_frontiers()
            return

        self.empty_scan_count = 0

        candidates = []
        for cluster in clusters:
            rows = [r for r, _ in cluster]
            cols = [c for _, c in cluster]
            wx, wy = self._cell_to_world(sum(rows) / len(rows), sum(cols) / len(cols), map_msg)
            dist = math.hypot(wx - rx, wy - ry)
            if dist < self.min_goal_distance:
                continue
            # skip frontiers we just tried, so a temporarily-unreachable one
            # doesn't get re-picked every single cycle
            if any(math.hypot(wx - vx, wy - vy) < self.min_goal_distance
                   for vx, vy in self.visited_frontiers[-5:]):
                continue
            candidates.append((dist, wx, wy, len(cluster)))

        if not candidates:
            self._handle_no_frontiers()
            return

        candidates.sort(key=lambda t: t[0])
        _, gx, gy, size = candidates[0]
        self.get_logger().info(
            f'Sending exploration goal -> ({gx:.2f}, {gy:.2f}) '
            f'[frontier size={size} cells, dist={candidates[0][0]:.2f} m]'
        )
        self._send_goal(gx, gy)

    def _handle_no_frontiers(self):
        self.empty_scan_count += 1
        self.get_logger().info(
            f'No reachable frontiers this cycle ({self.empty_scan_count}/{self.no_frontier_stop_count})'
        )
        if self.empty_scan_count >= self.no_frontier_stop_count:
            self.get_logger().info('Exploration complete: map appears fully explored. Stopping.')
            self.exploring = False

    # ---------- Nav2 action client ----------

    def _send_goal(self, x, y):
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = self.global_frame
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = x
        goal_msg.pose.pose.position.y = y
        goal_msg.pose.pose.orientation.w = 1.0

        self.goal_active = True
        self.goal_start_time = time.time()
        self.visited_frontiers.append((x, y))

        send_future = self.nav_client.send_goal_async(goal_msg)
        send_future.add_done_callback(self._goal_response_callback)

    def _goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().warn('Exploration goal rejected by Nav2.')
            self.goal_active = False
            return
        self.current_goal_handle = goal_handle
        result_future = goal_handle.get_result_future()
        result_future.add_done_callback(self._goal_result_callback)

    def _goal_result_callback(self, future):
        status = future.result().status
        if status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info('Exploration goal reached.')
        else:
            self.get_logger().warn(f'Exploration goal ended with status {status}.')
        self.goal_active = False
        self.current_goal_handle = None

    def _cancel_current_goal(self):
        if self.current_goal_handle is not None:
            self.current_goal_handle.cancel_goal_async()
        self.goal_active = False
        self.current_goal_handle = None


def main(args=None):
    rclpy.init(args=args)
    node = FrontierExplorer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()


if __name__ == '__main__':
    main()
