#!/usr/bin/env python3
"""
teleop_mapper.py

Manual SLAM mapping via keyboard teleop, all in one terminal:
  - WASD (or arrow-key style i/j/k/l) drives the robot over /cmd_vel
  - slam_toolbox (run separately via slam.launch.py) builds /map live
    from the driving
  - press 'm' at any time to save the currently-built map to disk via
    nav2_map_server's map_saver_cli -- "all mapping done by the robot"
    finishes with a single keypress, no separate terminal/command needed
  - 'q' quits (stops the robot first)

Usage:
    ros2 launch testbed_navigation slam.launch.py        # terminal 1 (builds /map)
    ros2 run testbed_navigation teleop_mapper.py          # terminal 2 (drive + save)
"""

import subprocess
import sys
import termios
import tty

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node

INSTRUCTIONS = """
Manual mapping teleop
----------------------------------------
   w        : forward
   s        : backward
   a        : rotate left
   d        : rotate right
   x        : stop

   +  / -   : increase / decrease speed

   m        : SAVE MAP  (finishes mapping)
   q        : quit (stops robot first)
----------------------------------------
"""


class TeleopMapper(Node):

    def __init__(self):
        super().__init__('teleop_mapper')

        self.declare_parameter('cmd_vel_topic', 'cmd_vel')
        self.declare_parameter('linear_speed', 0.2)     # m/s
        self.declare_parameter('angular_speed', 0.6)    # rad/s
        self.declare_parameter('speed_step', 0.05)
        self.declare_parameter('map_save_path', '')     # '' -> ~/testbed_map_<timestamp>

        cmd_vel_topic = self.get_parameter('cmd_vel_topic').value
        self.linear_speed = self.get_parameter('linear_speed').value
        self.angular_speed = self.get_parameter('angular_speed').value
        self.speed_step = self.get_parameter('speed_step').value
        self.map_save_path = self.get_parameter('map_save_path').value

        self.cmd_pub = self.create_publisher(Twist, cmd_vel_topic, 10)

    def publish_twist(self, lin, ang):
        msg = Twist()
        msg.linear.x = lin
        msg.angular.z = ang
        self.cmd_pub.publish(msg)

    def stop(self):
        self.publish_twist(0.0, 0.0)

    def save_map(self):
        """Trigger nav2_map_server's map_saver_cli against the running /map topic."""
        if self.map_save_path:
            out_path = self.map_save_path
        else:
            stamp = self.get_clock().now().to_msg().sec
            out_path = f'{__import__("os").path.expanduser("~")}/testbed_map_{stamp}'

        self.get_logger().info(f'Saving map to {out_path}.yaml / {out_path}.pgm ...')
        try:
            result = subprocess.run(
                [
                    'ros2', 'run', 'nav2_map_server', 'map_saver_cli',
                    '-f', out_path,
                    '--ros-args', '-p', 'save_map_timeout:=5.0',
                ],
                capture_output=True, text=True, timeout=15,
            )
            if result.returncode == 0:
                self.get_logger().info(f'Map saved: {out_path}.yaml')
            else:
                self.get_logger().error(
                    f'map_saver_cli failed (exit {result.returncode}): {result.stderr.strip()}'
                )
        except Exception as exc:  # noqa: BLE001 - report any failure, don't crash the teleop loop
            self.get_logger().error(f'Failed to invoke map_saver_cli: {exc}')

        return out_path


def get_key(settings):
    tty.setraw(sys.stdin.fileno())
    key = sys.stdin.read(1)
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key


def main(args=None):
    rclpy.init(args=args)
    node = TeleopMapper()

    if not sys.stdin.isatty():
        node.get_logger().error('teleop_mapper needs an interactive terminal (stdin is not a TTY).')
        node.destroy_node()
        rclpy.shutdown()
        return

    settings = termios.tcgetattr(sys.stdin)
    print(INSTRUCTIONS)

    lin_speed = node.linear_speed
    ang_speed = node.angular_speed

    try:
        while rclpy.ok():
            key = get_key(settings)

            if key == 'w':
                node.publish_twist(lin_speed, 0.0)
            elif key == 's':
                node.publish_twist(-lin_speed, 0.0)
            elif key == 'a':
                node.publish_twist(0.0, ang_speed)
            elif key == 'd':
                node.publish_twist(0.0, -ang_speed)
            elif key == 'x':
                node.stop()
            elif key == '+':
                lin_speed = min(lin_speed + node.speed_step, 1.0)
                ang_speed = min(ang_speed + node.speed_step, 2.0)
                print(f'speed -> linear={lin_speed:.2f} m/s, angular={ang_speed:.2f} rad/s')
            elif key == '-':
                lin_speed = max(lin_speed - node.speed_step, 0.0)
                ang_speed = max(ang_speed - node.speed_step, 0.0)
                print(f'speed -> linear={lin_speed:.2f} m/s, angular={ang_speed:.2f} rad/s')
            elif key == 'm':
                node.stop()
                print('\n>>> Saving map (mapping finished) ...')
                out_path = node.save_map()
                print(f'>>> Map saved to {out_path}.yaml / {out_path}.pgm\n')
            elif key == 'q':
                node.stop()
                break
            else:
                # unrecognized key: stop as a safety default, don't keep drifting
                node.stop()

    except Exception as exc:  # noqa: BLE001
        node.get_logger().error(f'teleop_mapper error: {exc}')
    finally:
        node.stop()
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
