# testbed_navigation

Manually assembled Nav2 navigation workflow for the `testbed` robot
(`ROS2Assignment` / Level 1: ROS2 Navigation Assignment).

Instead of calling `nav2_bringup`, this package wires up the individual
`nav2` plugins directly: `nav2_map_server`, `nav2_amcl`, `nav2_planner`,
`nav2_controller`, `nav2_behaviors`, `nav2_bt_navigator` and
`nav2_velocity_smoother`, each started as its own node and driven through
its lifecycle by a `nav2_lifecycle_manager` instance — mirroring what
`nav2_bringup`'s launch files do internally, but written out explicitly so
every component and its configuration is visible and independently
testable.

## Package layout

```
testbed_navigation/
├── CMakeLists.txt
├── package.xml
├── config/
│   ├── amcl_params.yaml          # AMCL localization parameters
│   ├── nav2_params.yaml          # planner / controller / behaviors / bt_navigator / costmaps / velocity_smoother
│   └── slam_toolbox_params.yaml  # slam_toolbox online-async mapping parameters
├── launch/
│   ├── map_loader.launch.py            # Stage 1: map_server only
│   ├── localization.launch.py          # Stage 2: map_server + amcl (against the fixed testbed_world map)
│   ├── navigation.launch.py            # Stage 3: planner + controller + behaviors + bt_navigator + velocity_smoother
│   ├── slam.launch.py                  # Alternative to stage 1+2: slam_toolbox builds the map live
│   └── autonomous_exploration.launch.py  # slam.launch.py + navigation.launch.py + frontier_explorer, one command
├── scripts/
│   └── frontier_explorer.py      # autonomous frontier-based exploration node
└── README.md
```

## Autonomous SLAM mapping (no pre-built map, no manual driving)

In addition to the assignment's manual map_server + AMCL localization
workflow, this package also supports building the map live with
`slam_toolbox` and exploring it fully autonomously — no `2D Pose Estimate`
clicks and no teleop needed.

**How it works:**
- `slam.launch.py` runs `slam_toolbox`'s online-async node in place of
  `map_loader.launch.py` + `localization.launch.py`. It publishes `/map`
  live from `/scan` and broadcasts `map -> odom`, so `navigation.launch.py`
  works completely unchanged on top of it.
- `scripts/frontier_explorer.py` is a small custom node: it looks at the
  live `/map`, finds "frontier" cells (free cells that border unmapped
  space), clusters them, and sends a `NavigateToPose` goal to the nearest
  sufficiently large frontier. It repeats this until no frontiers remain,
  at which point it declares the map fully explored and stops.
- `autonomous_exploration.launch.py` bundles `slam.launch.py` +
  `navigation.launch.py` + `frontier_explorer` into one launch file.

**Run it:**

```bash
# terminal 1
ros2 launch testbed_bringup testbed_full_bringup.launch.py

# terminal 2
ros2 launch testbed_navigation autonomous_exploration.launch.py
```

The robot will start driving itself toward unexplored space; `/map` fills
in as it goes. Watch progress in Rviz (`Map`, `LaserScan`, `TF` displays —
the existing `testbed_rviz.rviz` works fine here too). When the terminal 2
log prints `Exploration complete: map appears fully explored. Stopping.`,
save the finished map:

```bash
ros2 run nav2_map_server map_saver_cli -f ~/my_explored_map --ros-args -p save_map_timeout:=5.0
```

**Tuning knobs** (all exposed as ROS params on `frontier_explorer`):
| Param | Default | Meaning |
|---|---|---|
| `min_frontier_size` | 6 cells | ignore frontier clusters smaller than this (noise) |
| `min_goal_distance` | 0.5 m | don't re-target a frontier this close to one already visited |
| `goal_timeout` | 45 s | cancel a NavigateToPose goal that's taking too long and try another frontier |
| `exploration_rate` | 2.0 s | how often to re-scan the map for new frontiers |
| `no_frontier_stop_count` | 3 | consecutive empty scans before declaring exploration complete |

**Note:** `slam.launch.py` and `localization.launch.py` are mutually
exclusive — don't run both at once, since they'd fight over publishing
`map -> odom`. Use `localization.launch.py` when navigating on the known
`testbed_world` map, and `slam.launch.py` (or
`autonomous_exploration.launch.py`) when mapping a new/changed environment.

## Robot facts used to configure the stack

Pulled from `testbed_description/urdf/testbed.gazebo`:

| Item | Value |
|---|---|
| Base frame | `base_footprint` |
| Odom frame / topic | `odom` |
| Global frame | `map` |
| Lidar scan topic | `/scan` (300 samples, ±3.14 rad, 0.1–30 m) |
| Velocity command topic | `/cmd_vel` (`libgazebo_ros_diff_drive`) |
| Wheel separation / diameter | 0.35 m / 0.1 m |
| Robot spawn pose (`spawn_testbed.launch.py`) | x=0.0, y=5.0, yaw=0.0 |

The AMCL `initial_pose` in `amcl_params.yaml` is set to match the robot's
Gazebo spawn pose so localization converges immediately instead of needing
a manual 2D Pose Estimate in Rviz on every run.

## Running it (three independent stages)

Terminal 1 — bring up the simulation + robot (existing package, unchanged):

```bash
ros2 launch testbed_bringup testbed_full_bringup.launch.py
```

Terminal 2 — map loading only (confirms the map appears correctly before
anything else is started):

```bash
ros2 launch testbed_navigation map_loader.launch.py
```
Check in Rviz: add/keep the `Map` display, topic `/map`, and confirm the
`testbed_world` occupancy grid appears. Stop this launch file once
confirmed — `localization.launch.py` starts its own `map_server`.

Terminal 2 (again) — localization:

```bash
ros2 launch testbed_navigation localization.launch.py
```
Confirm in Rviz that the laser scan (`/scan`) aligns with the walls in the
map and that the `map -> odom -> base_footprint` TF chain is being
published (`ros2 run tf2_tools view_frames`). Drive the robot around with
`ros2 run teleop_twist_keyboard teleop_twist_keyboard` to watch the AMCL
particle cloud converge.

Terminal 3 — navigation:

```bash
ros2 launch testbed_navigation navigation.launch.py
```
Send a goal from Rviz (`2D Goal Pose`, using the existing
`testbed_rviz.rviz` config which already has the `SetGoal` and
`SetInitialPose` tools configured), or from the command line:

```bash
ros2 action send_goal /navigate_to_pose nav2_msgs/action/NavigateToPose \
  "{pose: {header: {frame_id: 'map'}, pose: {position: {x: 1.0, y: 4.0, z: 0.0}, orientation: {w: 1.0}}}}"
```

## Design choices

- **Plugins kept minimal on purpose** (per the assignment's "only basic
  navigational functionality is expected"):
  - Global planner: `nav2_navfn_planner/NavfnPlanner` (Dijkstra-based, no
    extra tuning needed for a static map).
  - Local controller: `dwb_core::DWBLocalPlanner` ("FollowPath") with a
    conservative velocity/acceleration envelope matched to the robot's
    small wheel separation.
  - Recovery behaviors: `spin`, `backup`, `wait` only (dropped
    `drive_on_heading`/`assisted_teleop` since they add nothing for this
    static, single-robot environment).
  - `nav2_velocity_smoother` included as the one "extra" plugin mentioned
    as optional in the assignment (`collision_monitor` was considered too,
    but skipped to keep the deliverable to "basic" scope — the costmap's
    inflation layer plus DWB's obstacle critic already provide the primary
    collision avoidance).
- **Three separate launch files, each independently runnable and each
  driving its own `nav2_lifecycle_manager`** — this follows the same
  split `nav2_bringup` uses internally (`localization_launch.py` /
  `navigation_launch.py`), which makes it possible to test map loading,
  then localization, then navigation, one step at a time, exactly as the
  assignment describes.
- `localization.launch.py` owns its own `map_server` node (rather than
  including `map_loader.launch.py`) so it is fully self-contained and can
  be launched on its own after the map has already been visually verified.
- `navigation.launch.py` assumes localization is already running and
  providing the `map -> odom` transform — it only manages the
  planning/control/behavior/BT stack.

## Challenges encountered

- **Plugin class-name format**: Nav2 on Humble expects the *slash* format
  (`"nav2_navfn_planner/NavfnPlanner"`, `"nav2_behaviors/Spin"`) for the
  planner and behavior plugins, while the costmap layers and the DWB
  controller use the *double-colon* format
  (`"nav2_costmap_2d::ObstacleLayer"`, `"dwb_core::DWBLocalPlanner"`).
  Mixing these up produces `pluginlib` "class not found" errors at
  lifecycle configure time.
- **cmd_vel chain**: with `velocity_smoother` in the stack, the
  `controller_server`'s `cmd_vel` output has to be remapped to an
  intermediate topic (`cmd_vel_nav`) and the smoother remapped to consume
  `cmd_vel_nav` / publish `cmd_vel_smoothed` -> `cmd_vel`, otherwise both
  nodes fight over publishing the same topic (fixed in
  `navigation.launch.py`'s `remappings`).
- **Initial pose**: because the robot spawns at `(0, 5)` in Gazebo rather
  than the map origin, AMCL's default `(0, 0, 0)` initial pose put the
  particle cloud outside the corridor the robot actually starts in. Set
  `initial_pose` in `amcl_params.yaml` to the real spawn pose instead of
  relying on manual `2D Pose Estimate` clicks in Rviz.
- **`use_sim_time`**: every node in every stage needs it set consistently
  to `True` (matching Gazebo's `/clock`), or lifecycle bring-up stalls
  waiting on TF/time-synced data that never arrives.

## Testing performed

- `map_loader.launch.py` verified independently: `/map` topic publishing,
  correct occupancy grid visible in Rviz, `ros2 lifecycle get map_server`
  reports `active`.
- `localization.launch.py` verified independently: `map -> odom` TF
  present, `/particle_cloud` converges around the robot's true pose after
  a short teleop drive, AMCL pose covariance shrinks.
- `navigation.launch.py` verified end-to-end with `map_loader` +
  `localization` already running: `NavigateToPose` goals sent from Rviz
  and from the CLI are accepted, a global plan is computed and published
  on `/plan`, and the robot drives to the goal, stopping within the
  configured `xy_goal_tolerance`.
