#!/usr/bin/env python3
"""
autonomous_exploration.launch.py

One-command autonomous SLAM mapping:
  - slam_toolbox (online async) builds the map live and publishes
    /map + map -> odom
  - the manual nav2 stack (planner, controller, behavior_server,
    bt_navigator, velocity_smoother) drives the robot to goals
  - frontier_explorer autonomously picks unexplored frontier goals and
    sends them to Nav2 -- no manual teleop needed

Run testbed_bringup's simulation first, then this single launch file.

Usage:
    ros2 launch testbed_bringup testbed_full_bringup.launch.py     # terminal 1
    ros2 launch testbed_navigation autonomous_exploration.launch.py  # terminal 2
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_testbed_navigation = get_package_share_directory('testbed_navigation')

    use_sim_time = LaunchConfiguration('use_sim_time')

    declare_use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='True',
        description='Use simulation (Gazebo) clock if true',
    )

    slam = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_testbed_navigation, 'launch', 'slam.launch.py')
        ),
        launch_arguments={'use_sim_time': use_sim_time}.items(),
    )

    navigation = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_testbed_navigation, 'launch', 'navigation.launch.py')
        ),
        launch_arguments={'use_sim_time': use_sim_time}.items(),
    )

    frontier_explorer_node = Node(
        package='testbed_navigation',
        executable='frontier_explorer.py',
        name='frontier_explorer',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time,
            'map_topic': 'map',
            'global_frame': 'map',
            'robot_base_frame': 'base_footprint',
            'min_frontier_size': 6,
            'min_goal_distance': 0.5,
            'goal_timeout': 45.0,
            'exploration_rate': 2.0,
            'no_frontier_stop_count': 3,
        }],
    )

    return LaunchDescription([
        declare_use_sim_time_arg,
        slam,
        navigation,
        frontier_explorer_node,
    ])
