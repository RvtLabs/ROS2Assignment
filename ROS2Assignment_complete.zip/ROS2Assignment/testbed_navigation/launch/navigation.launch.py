#!/usr/bin/env python3
"""
navigation.launch.py

Brings up the navigation ("move base") workflow manually, plugin by plugin,
instead of calling nav2_bringup:
  - nav2_planner            (global planner: NavfnPlanner)
  - nav2_controller          (local controller: DWBLocalPlanner, "FollowPath")
  - nav2_behaviors           (recovery behaviors: spin, backup, wait)
  - nav2_bt_navigator        (behavior tree that ties planner/controller/
                               behaviors together to serve NavigateToPose /
                               NavigateThroughPoses actions)
  - nav2_velocity_smoother   (smooths the controller's cmd_vel output)
  - nav2_lifecycle_manager   (drives all of the above through
                               configure -> activate, in order)

This launch file assumes localization (map_server + amcl, providing the
map -> odom transform) is already running -- e.g. via
`ros2 launch testbed_navigation localization.launch.py` -- exactly like
nav2_bringup splits localization_launch.py from navigation_launch.py.

Usage:
    ros2 launch testbed_navigation navigation.launch.py
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_testbed_navigation = get_package_share_directory('testbed_navigation')
    default_params_file = os.path.join(
        pkg_testbed_navigation, 'config', 'nav2_params.yaml'
    )

    params_file = LaunchConfiguration('params_file')
    use_sim_time = LaunchConfiguration('use_sim_time')
    autostart = LaunchConfiguration('autostart')

    declare_params_arg = DeclareLaunchArgument(
        'params_file',
        default_value=default_params_file,
        description='Full path to the navigation parameter file (planner, controller, behaviors, bt_navigator, costmaps)',
    )

    declare_use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='True',
        description='Use simulation (Gazebo) clock if true',
    )

    declare_autostart_arg = DeclareLaunchArgument(
        'autostart',
        default_value='True',
        description='Automatically bring the navigation servers to the active state',
    )

    controller_server_node = Node(
        package='nav2_controller',
        executable='controller_server',
        name='controller_server',
        output='screen',
        parameters=[params_file, {'use_sim_time': use_sim_time}],
        # Controller publishes raw cmd_vel; velocity_smoother re-publishes the
        # smoothed version on the real /cmd_vel topic consumed by the diff-drive plugin.
        remappings=[('cmd_vel', 'cmd_vel_nav')],
    )

    planner_server_node = Node(
        package='nav2_planner',
        executable='planner_server',
        name='planner_server',
        output='screen',
        parameters=[params_file, {'use_sim_time': use_sim_time}],
    )

    behavior_server_node = Node(
        package='nav2_behaviors',
        executable='behavior_server',
        name='behavior_server',
        output='screen',
        parameters=[params_file, {'use_sim_time': use_sim_time}],
    )

    bt_navigator_node = Node(
        package='nav2_bt_navigator',
        executable='bt_navigator',
        name='bt_navigator',
        output='screen',
        parameters=[params_file, {'use_sim_time': use_sim_time}],
    )

    velocity_smoother_node = Node(
        package='nav2_velocity_smoother',
        executable='velocity_smoother',
        name='velocity_smoother',
        output='screen',
        parameters=[params_file, {'use_sim_time': use_sim_time}],
        remappings=[('cmd_vel', 'cmd_vel_nav'), ('cmd_vel_smoothed', 'cmd_vel')],
    )

    lifecycle_manager_node = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='lifecycle_manager_navigation',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time,
            'autostart': autostart,
            'node_names': [
                'controller_server',
                'planner_server',
                'behavior_server',
                'bt_navigator',
                'velocity_smoother',
            ],
        }],
    )

    return LaunchDescription([
        declare_params_arg,
        declare_use_sim_time_arg,
        declare_autostart_arg,
        controller_server_node,
        planner_server_node,
        behavior_server_node,
        bt_navigator_node,
        velocity_smoother_node,
        lifecycle_manager_node,
    ])
