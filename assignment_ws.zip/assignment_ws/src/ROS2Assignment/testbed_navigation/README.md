# testbed_navigation

Manual (non `nav2_bringup`) navigation stack for the `testbed` robot from
[RvtLabs/ROS2Assignment](https://github.com/RvtLabs/ROS2Assignment): map
loading, localization, and navigation are each their own launch file,
built directly from individual `nav2` plugins per the assignment brief.

## Package layout

```
testbed_navigation/
├── CMakeLists.txt
├── package.xml
├── config/
│   ├── amcl_params.yaml       # AMCL tuning
│   └── nav2_params.yaml       # controller/planner/behavior/bt_navigator/
│                               # waypoint_follower/velocity_smoother/
│                               # collision_monitor
├── launch/
│   ├── map_loader.launch.py                 # step 4
│   ├── localization.launch.py                # step 5
│   ├── navigation.launch.py                  # step 6
│   └── testbed_navigation_bringup.launch.py   # everything, one command
├── scripts/
│   └── send_nav_goal.py       # BasicNavigator CLI helper for step 6 testing
└── README.md
```

## Robot facts used to configure the stack

Pulled directly from `testbed_description/urdf/testbed.gazebo` and
`testbed_description/urdf/testbed.xacro` rather than assumed, since the
assignment's plugin-level configuration only works if these match the
actual robot exactly:

| Fact | Value | Source |
|---|---|---|
| Base frame | `base_footprint` | `robot_base_frame` in `libgazebo_ros_diff_drive` |
| Odom frame | `odom` | same plugin |
| Scan topic | `/scan` | `libgazebo_ros_ray_sensor` remap `~/out:=scan` |
| Cmd vel topic | `/cmd_vel` | `command_topic` in diff_drive plugin |
| Wheel separation | 0.35 m | diff_drive plugin |
| Spawn pose | x=0, y=5, yaw=0 | `testbed_gazebo/launch/spawn_testbed.launch.py` |
| Map file | `testbed_bringup/maps/testbed_world.yaml`, res 0.05, origin [-10.2, -9.94, 0] | provided map |

## Approach

1. **Map loading (`map_loader.launch.py`)** — a standalone `nav2_map_server`
   node plus a dedicated `lifecycle_manager` (`node_names: [map_server]`).
   `map_server` is a managed nav2 node: it will accept the `yaml_filename`
   parameter but will **not** start publishing `/map` until something
   walks it through `configure()` → `activate()`, hence the lifecycle
   manager even for this single node. Kept in its own launch file so it
   can be started and checked in Rviz (`ros2 launch testbed_navigation
   map_loader.launch.py`, then add a `Map` display in Rviz) before
   touching localization or navigation.

2. **Localization (`localization.launch.py`)** — `nav2_amcl` + its own
   `lifecycle_manager`. Includes `map_loader.launch.py` by default so the
   file is runnable standalone (`use_map_loader:=false` to skip that if
   the map is already up). `amcl_params.yaml` sets `base_frame_id:
   base_footprint` / `odom_frame_id: odom` / `scan_topic: scan` to match
   the robot exactly, uses the differential-drive motion model (matching
   `libgazebo_ros_diff_drive`), and seeds `initial_pose` at the robot's
   actual Gazebo spawn point (0, 5, yaw 0) so the particle filter starts
   converged instead of scattered across the whole map.

3. **Navigation (`navigation.launch.py`)** — `controller_server` (DWB),
   `planner_server` (NavFn), `behavior_server` (spin / back_up / wait /
   drive_on_heading), `bt_navigator` (default nav2 behavior tree —
   sufficient for "basic navigational functionality" per the brief),
   `waypoint_follower`, `velocity_smoother`, and `collision_monitor`, all
   under one shared `lifecycle_manager`. `cmd_vel` is chained explicitly
   through remappings so each stage can't accidentally publish straight
   to the robot and skip smoothing/collision-checking:

   ```
   controller_server --/cmd_vel_nav--> velocity_smoother
                     --/cmd_vel_smoothed--> collision_monitor
                     --/cmd_vel--> gazebo diff_drive plugin
   ```

4. **`testbed_navigation_bringup.launch.py`** — includes
   `testbed_full_bringup.launch.py` from `testbed_bringup`, then the three
   files above in order, using `TimerAction` delays (8s / 10s / 13s) so
   `map_server`/`amcl`/the nav2 servers aren't started before Gazebo has
   actually spawned the robot and TF is flowing. This mirrors the
   spawn-race issues that show up if Nav2 comes up before
   `robot_state_publisher` and the Gazebo spawn have settled.

5. **`scripts/send_nav_goal.py`** — thin `BasicNavigator` wrapper so goals
   can be sent from the CLI (`ros2 run testbed_navigation
   send_nav_goal.py --x 2.0 --y 4.0`) without hand-rolling an action
   client, for the manual navigation testing in step 6.

## Running it

```bash
cd ~/assignment_ws
colcon build
source install/setup.bash

# One-shot, full stack:
ros2 launch testbed_navigation testbed_navigation_bringup.launch.py

# Or stage by stage, in separate terminals, for debugging:
ros2 launch testbed_bringup testbed_full_bringup.launch.py
ros2 launch testbed_navigation map_loader.launch.py
ros2 launch testbed_navigation localization.launch.py use_map_loader:=false
ros2 launch testbed_navigation navigation.launch.py

# Send a test goal once AMCL has converged:
ros2 run testbed_navigation send_nav_goal.py --x 2.0 --y 4.0 --yaw 0.0
```

Sanity checks while bringing each stage up, per `help.md`'s advice to
test independently:

```bash
ros2 topic echo /map --once                 # after map_loader
ros2 run tf2_tools view_frames              # after localization: map->odom->base_footprint
ros2 topic echo /amcl_pose --once           # AMCL converged if covariance is small
ros2 action list                            # after navigation: /navigate_to_pose should exist
```

## Challenges & fixes

- **DWB "No critics defined for FollowPath"** — DWB's controller plugin
  will not activate with an empty or missing `critics` list; the
  `controller_server` crashes on `configure()`. Fixed by explicitly
  listing all 7 critics (`RotateToGoal`, `Oscillation`, `BaseObstacle`,
  `GoalAlign`, `PathAlign`, `PathDist`, `GoalDist`) under `FollowPath` in
  `nav2_params.yaml`, each with tuned scale parameters.
- **Lifecycle activation ordering** — every nav2 node here is a managed
  lifecycle node; none of them do anything useful until a
  `lifecycle_manager` explicitly configures + activates them. Rather than
  one manager for the whole stack, `map_server`, `amcl`, and the
  navigation servers each get their own manager so a given stage can be
  restarted independently while debugging (matches the "test components
  independently" guidance in `help.md`).
- **Frame/topic mismatches** — the biggest source of silent failures
  (AMCL never converging, costmaps never populating) came from
  copy-pasted example configs assuming `base_link`/default topic names.
  Every frame and topic in `amcl_params.yaml` and `nav2_params.yaml` was
  pulled directly from `testbed.gazebo` instead of assumed.
- **`use_sim_time`** — set to `true` on every single node/lifecycle
  manager in this package; Gazebo publishes `/clock` and TF timestamps
  are on sim time, so any node left on wall-clock time (the ROS2
  default) ends up with a stale/rejected TF tree against `use_sim_time`
  nodes.
- **cmd_vel double-publishing** — with `velocity_smoother` and
  `collision_monitor` both able to write to `/cmd_vel`, it's easy to end
  up with two nodes fighting over the topic if remappings aren't
  explicit. Solved by remapping `controller_server`'s output to
  `cmd_vel_nav` and chaining `cmd_vel_nav -> cmd_vel_smoothed -> cmd_vel`
  through the smoother and collision monitor in series (see topic table
  above), so exactly one node ever publishes the final `/cmd_vel`.
