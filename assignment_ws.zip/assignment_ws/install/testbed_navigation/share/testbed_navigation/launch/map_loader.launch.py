#!/usr/bin/env python3
"""
map_loader.launch.py

Brings up the nav2_map_server node on its own, publishing the static
occupancy grid (map -> /map topic + map -> odom-free "map" frame source)
from the pre-built testbed_bringup map. A dedicated lifecycle_manager is
used because map_server is a managed (nav2 lifecycle) node and will not
start serving the map until it is explicitly configured + activated.

This is intentionally kept independent of localization.launch.py and
navigation.launch.py so each stage of the pipeline (map -> localization ->
navigation) can be started, tested and killed on its own, per the
assignment's "test components independently" guidance.
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    testbed_bringup_dir = get_package_share_directory('testbed_bringup')
    default_map_yaml = os.path.join(
        testbed_bringup_dir, 'maps', 'testbed_world.yaml'
    )

    map_yaml_arg = DeclareLaunchArgument(
        'map',
        default_value=default_map_yaml,
        description='Full path to the map yaml file to load',
    )
    use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',
        description='Use simulation (Gazebo) clock if true',
    )
    autostart_arg = DeclareLaunchArgument(
        'autostart',
        default_value='true',
        description='Automatically configure/activate map_server on launch',
    )

    map_yaml_file = LaunchConfiguration('map')
    use_sim_time = LaunchConfiguration('use_sim_time')
    autostart = LaunchConfiguration('autostart')

    map_server_node = Node(
        package='nav2_map_server',
        executable='map_server',
        name='map_server',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time,
            'yaml_filename': map_yaml_file,
        }],
    )

    # map_server is a nav2 managed/lifecycle node -> needs a lifecycle
    # manager to walk it through configure() -> activate().
    lifecycle_manager_node = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='lifecycle_manager_map_server',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time,
            'autostart': autostart,
            'node_names': ['map_server'],
        }],
    )

    return LaunchDescription([
        map_yaml_arg,
        use_sim_time_arg,
        autostart_arg,
        map_server_node,
        lifecycle_manager_node,
    ])
