#!/usr/bin/env python3
"""
localization.launch.py

Runs AMCL against the map published by map_loader.launch.py. AMCL is also
a managed nav2 lifecycle node, so it gets its own lifecycle_manager here
(bundling it with map_server's lifecycle_manager would work too, but
keeping them separate lets you kill/restart localization without tearing
down the map server, which is convenient while iterating on
amcl_params.yaml).

By default this launch file ALSO brings up map_loader.launch.py so
`ros2 launch testbed_navigation localization.launch.py` is self-contained.
Pass `use_map_loader:=false` if you are already running map_loader
separately (e.g. while testing each stage independently).
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node


def generate_launch_description():
    pkg_testbed_navigation = get_package_share_directory('testbed_navigation')

    default_amcl_yaml = os.path.join(
        pkg_testbed_navigation, 'config', 'amcl_params.yaml'
    )

    params_file_arg = DeclareLaunchArgument(
        'params_file',
        default_value=default_amcl_yaml,
        description='Full path to the AMCL parameters yaml file',
    )
    use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',
        description='Use simulation (Gazebo) clock if true',
    )
    autostart_arg = DeclareLaunchArgument(
        'autostart',
        default_value='true',
        description='Automatically configure/activate amcl on launch',
    )
    use_map_loader_arg = DeclareLaunchArgument(
        'use_map_loader',
        default_value='true',
        description='Also bring up map_loader.launch.py in this file',
    )

    params_file = LaunchConfiguration('params_file')
    use_sim_time = LaunchConfiguration('use_sim_time')
    autostart = LaunchConfiguration('autostart')

    map_loader = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution(
                [pkg_testbed_navigation, 'launch', 'map_loader.launch.py']
            )
        ),
        condition=IfCondition(LaunchConfiguration('use_map_loader')),
    )

    amcl_node = Node(
        package='nav2_amcl',
        executable='amcl',
        name='amcl',
        output='screen',
        parameters=[params_file, {'use_sim_time': use_sim_time}],
    )

    lifecycle_manager_node = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='lifecycle_manager_localization',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time,
            'autostart': autostart,
            'node_names': ['amcl'],
        }],
    )

    return LaunchDescription([
        params_file_arg,
        use_sim_time_arg,
        autostart_arg,
        use_map_loader_arg,
        map_loader,
        amcl_node,
        lifecycle_manager_node,
    ])
