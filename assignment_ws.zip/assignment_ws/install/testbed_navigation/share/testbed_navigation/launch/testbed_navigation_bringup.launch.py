#!/usr/bin/env python3
"""
testbed_navigation_bringup.launch.py

Convenience launch file that stacks everything needed for a full,
end-to-end run in one command:

    ros2 launch testbed_navigation testbed_navigation_bringup.launch.py

Order matters here and is enforced with TimerAction delays because
map_server / amcl / the nav2 servers all depend on TF and topics that
only exist once Gazebo has spawned the robot and robot_state_publisher
is broadcasting:

  t=0s   testbed_full_bringup (Gazebo + robot_state_publisher + spawn + Rviz)
  t=20s  map_loader   (map_server + its lifecycle_manager)
  t=28s  localization (amcl + its lifecycle_manager) -- use_map_loader:=false
         since map_loader was already started above
  t=35s  navigation    (controller/planner/behavior/bt_navigator/... )

These delays are deliberately generous for software-rendered Gazebo
(llvmpipe/SVGA, e.g. a VM without GPU passthrough) where spawning the
robot and getting /scan flowing can take well over 10s. If RViz still
shows "Fixed Frame [map] does not exist" after this launch settles,
that means AMCL hasn't broadcast map->odom yet -- almost always because
it started before /scan was actually being published. Check with
`ros2 topic hz /scan` and `ros2 lifecycle get amcl` before increasing
these delays further.

If any stage fails to activate, run the corresponding launch file
(map_loader.launch.py / localization.launch.py / navigation.launch.py)
on its own in a separate terminal against the already-running
simulation -- this is far easier to debug than the combined stack.
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution


def generate_launch_description():
    pkg_testbed_bringup = get_package_share_directory('testbed_bringup')
    pkg_testbed_navigation = get_package_share_directory('testbed_navigation')

    full_bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                pkg_testbed_bringup, 'launch', 'testbed_full_bringup.launch.py'
            )
        )
    )

    map_loader = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution(
                [pkg_testbed_navigation, 'launch', 'map_loader.launch.py']
            )
        )
    )

    localization = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution(
                [pkg_testbed_navigation, 'launch', 'localization.launch.py']
            )
        ),
        launch_arguments={'use_map_loader': 'false'}.items(),
    )

    navigation = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution(
                [pkg_testbed_navigation, 'launch', 'navigation.launch.py']
            )
        )
    )

    return LaunchDescription([
        full_bringup,
        # These delays are intentionally generous. On software-rendered
        # Gazebo (llvmpipe/SVGA, e.g. VMware without GPU passthrough),
        # spawning the robot and getting robot_state_publisher + /scan
        # flowing can take well over 10s on its own. If map_loader /
        # localization / navigation start before /scan is actually being
        # published, AMCL never gets a scan to localize against and will
        # never broadcast the map->odom transform, which is what causes
        # RViz's "Fixed Frame [map] does not exist" / "Frame [map] does
        # not exist" warning. If you still see that warning, first check
        # `ros2 topic hz /scan` is publishing BEFORE these timers fire;
        # if Gazebo is slower than that on your machine, increase these
        # further rather than debugging AMCL itself.
        TimerAction(period=20.0, actions=[map_loader]),
        TimerAction(period=28.0, actions=[localization]),
        TimerAction(period=35.0, actions=[navigation]),
    ])
