#!/usr/bin/env python3
"""
send_nav_goal.py

Small manual-test helper for step 6 of the assignment ("Test the
navigation setup by sending goals to the robot and observing its
behavior."). Wraps nav2_simple_commander's BasicNavigator so you don't
have to hand-build an action client just to smoke-test the stack.

Usage:
    ros2 run testbed_navigation send_nav_goal.py --x 2.0 --y 4.0 --yaw 0.0

Requires localization.launch.py and navigation.launch.py (or
testbed_navigation_bringup.launch.py) to already be running, and AMCL
to have converged to a reasonable pose estimate first (drive the robot
a little with teleop, or nudge the initial pose in Rviz, if the
particle cloud looks spread out).
"""
import argparse
import sys

import rclpy
from rclpy.utilities import remove_ros_args
from geometry_msgs.msg import PoseStamped
from tf_transformations import quaternion_from_euler
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult


def build_pose(navigator, x, y, yaw):
    pose = PoseStamped()
    pose.header.frame_id = 'map'
    pose.header.stamp = navigator.get_clock().now().to_msg()
    pose.pose.position.x = x
    pose.pose.position.y = y
    q = quaternion_from_euler(0.0, 0.0, yaw)
    pose.pose.orientation.x = q[0]
    pose.pose.orientation.y = q[1]
    pose.pose.orientation.z = q[2]
    pose.pose.orientation.w = q[3]
    return pose


def main():
    rclpy.init()

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--x', type=float, required=True, help='Goal X in map frame')
    parser.add_argument('--y', type=float, required=True, help='Goal Y in map frame')
    parser.add_argument('--yaw', type=float, default=0.0, help='Goal yaw (rad)')
    args = parser.parse_args(args=remove_ros_args(sys.argv)[1:])

    navigator = BasicNavigator()
    navigator.waitUntilNav2Active()

    goal_pose = build_pose(navigator, args.x, args.y, args.yaw)
    navigator.goToPose(goal_pose)

    while not navigator.isTaskComplete():
        feedback = navigator.getFeedback()
        if feedback:
            navigator.get_logger().info(
                f'Distance remaining: {feedback.distance_remaining:.2f} m'
            )

    result = navigator.getResult()
    if result == TaskResult.SUCCEEDED:
        navigator.get_logger().info('Goal reached.')
    elif result == TaskResult.CANCELED:
        navigator.get_logger().warn('Goal was canceled.')
    elif result == TaskResult.FAILED:
        navigator.get_logger().error('Goal failed.')

    if rclpy.ok():
        rclpy.shutdown()


if __name__ == '__main__':
    main()
